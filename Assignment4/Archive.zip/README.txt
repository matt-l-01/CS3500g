README - SIMPLE IMAGE EDITOR PROGRAM - MATTHEW LOVE & RITU SHAH

This program may take in a ".ppm" image file, and may conduct certain operations on the image before saving. First, take in the image and load it. Then, conduct any operations of the following on the image: brighten, darken, vertical flip, horizontal flip, value component, intensity component, luma component, red component, green component, or blue component. Lastly, save the file either overriding the original file, or creating a new one. The commands for all these operations will be listed at the bottom of this file.

When you load an image, the program stores that image in memory with the specified name. What this means is that multiple images may be stored in memory in one concurrent run, and may have different operations conducted on them.

Design: At a higher level, the program contains interfaces for the ImageEditor controller, model, state, and view. These interfaces are implemented in the SimpleImageEditor controller, model, and view. The model runs the actual operations on the saved images in memory. The controller runs the program by accepting inputs and using the model. The view handles the outputs to the user, such as the text feedback in the command line. The ImageEditorState is used within the SimpleImageView class in order to limit the accessibility of the model when being used by the view. For example, the view does not need to conduct operations on the model, so there is no need to give it access to those methods. The Component class is an enum and used when determining the type of component to show (whether it is the red, green, blue, luma, intensity, or value component). The Pixel class represents one pixel with values of RGB. Lastly, included are test files for all the components of the program.

Classes & Interfaces:
Component 
ImageEditorController
ImageEditorModel
ImageEditorState
ImageEditorView
Pixel
SimpleEditorController
SimpleEditorModel
SimpleEditorView
PixelTest
SimpleImageControllerTest
SimpleImageEditorTest
SimpleImageViewTest

SCRIPT - Loading a file, conducting operations, and saving to another file.
Type the following commands when the program runs:
- load res/Flowers_orig.ppm flowers
- brighten 50 flowers flowers_bright
- vertical-flip flowers_bright flowers_vert_bright
- green-component flowers_vert_bright flowers_vert_bright_grey
- save res/Flowers_final.ppm flowers_vert_bright_grey

The above script will load the original flowers file, brighten the image by 50, flip the image vertically, show only the green component (greyscale), and lastly save the image to a new file under the path of "res/Flowers_final.ppm".

Commands:
- load <path> <save-name> - Load an image using the given path, and saving it with the given name.
- save <path> <save-name> - Saves the specified image to the given path.
- brighten <value> <image-name> <save-name> - Brightens an image to the value (pos/neg) and saves to the new name. A negative number indicates darkening.
- vertical-flip <image-name> <save-name> - Flips the image vertically and saves to the new name.
- horizontal-flip <image-name> <save-name> - Flips the image horizontally and saves to the new name.
- value-component <image-name> <save-name> - Converts the image to show the value component and saves to the new name.
- intensity-component <image-name> <save-name> - Converts the image to show the intensity component and saves to the new name.
- luma-component <image-name> <save-name> - Converts the image to show the luma component and saves to the new name.
- red-component <image-name> <save-name> - Converts the image to show the red component and saves to the new name.
- green-component <image-name> <save-name> - Converts the image to show the green component and saves to the new name.
- blue-component <image-name> <save-name> - Converts the image to show the blue component and saves to the new name.
- menu - Shows the menu screen again with all the commands.
- q - if you would like to quit the program.

Flowers Image Citation:
Roche, Daniel S. “Flowers.” IC210: Project1 , Department of Computer Science, https://www.usna.edu/Users/cs/choi/ic210/project/p01/index.html. Accessed 2 Nov. 2021.
